
# 7章 グローバルなState管理

- 7-2 ContextでのState管理までで実装した最終形のソースを配置しています。復習に活用してください。
- create-react-appで作成しています
- yarnを使用しています

## 確認方法

- create-react-appで作成しています。ローカルで動作させたい場合はクローンしてご利用ください。
- また、以下のリンクからCodeSandboxで確認することもできます

[https://codesandbox.io/s/react-book-7-global-state-dwh5o](https://codesandbox.io/s/react-book-7-global-state-dwh5o)
