# 3章 JavaScriptでのDOM操作

- 3-3 JavaScriptによるDOM操作の実践 で実装した最終形のソースを配置しています。復習に活用してください。

## 確認方法

- ローカルで動作させたい場合はクローンしてご利用ください。
- また、以下のリンクからCodeSandboxで確認することもできます。

[https://codesandbox.io/s/react-book-3-js-dom-ugtsn](https://codesandbox.io/s/react-book-3-js-dom-ugtsn)
