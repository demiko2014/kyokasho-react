
# React×TypeScript実践演習

- React×TypeScript実践演習で実装した最終形のソースを配置しています。復習に活用してください。
- create-react-appで作成しています
- yarnを使用しています

## 確認方法

- create-react-appで作成しています。ローカルで動作させたい場合はクローンしてご利用ください。
- また、以下のリンクからCodeSandboxで確認することもできます

[https://codesandbox.io/s/react-book-appendix-react-typescript-app-4h6ux](https://codesandbox.io/s/react-book-appendix-react-typescript-app-4h6ux)
