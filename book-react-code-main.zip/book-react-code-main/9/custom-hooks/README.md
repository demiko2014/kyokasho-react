
# 9章 カスタムフック

- 9-3 カスタムフックの実行までで実装した最終形のソースを配置しています。復習に活用してください。
- APIの実行先は実際には存在しないため、確認する際は固定で取得想定のデータをStateに設定する等して確認してください。
- create-react-appで作成しています
- yarnを使用しています

## 確認方法

- create-react-appで作成しています。ローカルで動作させたい場合はクローンしてご利用ください。
- また、以下のリンクからCodeSandboxで確認することもできます

[https://codesandbox.io/s/react-book-9-custom-hooks-uy5ii](https://codesandbox.io/s/react-book-9-custom-hooks-uy5ii)
