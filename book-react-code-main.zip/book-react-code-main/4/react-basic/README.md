
# 4章 Reactの基本

- 4-6 State(useState)までで実装した最終形のソースを配置しています。復習に活用してください。
- create-react-appで作成しています
- yarnを使用しています

## 確認方法

- create-react-appで作成しています。ローカルで動作させたい場合はクローンしてご利用ください。
- また、以下のリンクからCodeSandboxで確認することもできます

[https://codesandbox.io/s/react-book-4-react-basic-cxh1x](https://codesandbox.io/s/react-book-4-react-basic-cxh1x)
