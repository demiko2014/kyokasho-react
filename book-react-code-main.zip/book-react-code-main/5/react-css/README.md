
# 5章 ReactとCSS

- 各CSSライブラリを使用した例のファイルを配置しています
- create-react-appで作成しています
- yarnを使用しています

## 確認方法

- create-react-appで作成しています。ローカルで動作させたい場合はクローンしてご利用ください。
- また、以下のリンクからCodeSandboxで確認することもできます(TailwindはCRACOを使用する関係でCodeSandboxで上手く表示されていません)

[https://codesandbox.io/s/react-book-5-react-css-umr05](https://codesandbox.io/s/react-book-5-react-css-umr05)
